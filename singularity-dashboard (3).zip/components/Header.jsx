/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/
import React from 'react';
import { Cpu, Activity, ShieldCheck, Zap, Volume2, VolumeX } from 'lucide-react';

const Header = ({
  phase = 'AGI',
  stageName = 'Младенчество',
  stageIcon = '🌱',
  qecFidelity = 99.42,
  omnisOpcode = 'Q_HADAMARD',
  simSpeed = 1,
  onSimSpeedChange,
  soundEnabled = false,
  onToggleSound,
  onOpenManifesto,
}) => {
  const getPhaseBadge = () => {
    switch (phase) {
      case 'AGI':
        return (
          <div className="text-xs font-mono px-3 py-1 rounded bg-cyan-950/90 text-cyan-300 border border-cyan-500/40 shadow-sm">
            ФАЗА: AGI [САМООРГАНИЗАЦИЯ]
          </div>
        );
      case 'ASI':
        return (
          <div className="text-xs font-mono px-3 py-1 rounded bg-purple-950/90 text-purple-300 border border-purple-500/50 animate-pulse shadow-sm">
            ФАЗА: ASI [СВЕРХРАЗУМ]
          </div>
        );
      case 'POST_SINGULARITY':
        return (
          <div className="text-xs font-mono px-3 py-1 rounded bg-emerald-950/90 text-emerald-300 border border-emerald-400/60 shadow-sm shadow-emerald-500/20">
            ФАЗА: ПОСТ-СИНГУЛЯРНОСТЬ [Ω]
          </div>
        );
      default:
        return null;
    }
  };

  return (
    <header className="px-4 py-2.5 bg-[#080b10] border-b border-cyan-900/40 flex flex-wrap items-center justify-between gap-3 z-20">
      {/* Unified System Identity */}
      <div className="flex items-center gap-3">
        <div className="w-9 h-9 rounded-lg bg-gradient-to-br from-cyan-500/20 via-purple-500/20 to-emerald-500/20 border border-cyan-500/40 flex items-center justify-center text-cyan-300 shadow-inner">
          <Cpu size={20} className="animate-pulse" />
        </div>
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-sm sm:text-base font-bold text-white tracking-wider font-mono">
              RESONANCE-MATRIX³ <span className="text-cyan-400">vΩ</span>
            </h1>
            <span className="hidden md:inline-block text-[10px] font-mono px-2 py-0.5 rounded bg-gray-900 text-gray-400 border border-gray-800">
              OMNIS RV32T ⊕ MATRIX³ ⊕ CIS
            </span>
          </div>
          <p className="text-[11px] text-gray-400 font-mono">
            Единая эволюционирующая когнитивно-квантовая система ИИ
          </p>
        </div>
      </div>

      {/* Live Kernel Telemetry Bar */}
      <div className="hidden xl:flex items-center gap-4 bg-[#0d121a] px-3.5 py-1.5 rounded-lg border border-gray-800/80 text-xs font-mono">
        <div className="flex items-center gap-1.5 text-gray-300">
          <span>{stageIcon}</span>
          <span className="text-gray-500">Стадия:</span>
          <span className="text-cyan-300 font-semibold">{stageName}</span>
        </div>
        <div className="h-3 w-[1px] bg-gray-800" />
        <div className="flex items-center gap-1.5">
          <ShieldCheck size={14} className="text-emerald-400" />
          <span className="text-gray-500">QEC:</span>
          <span className="text-emerald-300 font-semibold">{Number(qecFidelity).toFixed(2)}%</span>
        </div>
        <div className="h-3 w-[1px] bg-gray-800" />
        <div className="flex items-center gap-1.5">
          <Activity size={14} className="text-purple-400" />
          <span className="text-gray-500">OMNIS:</span>
          <span className="text-purple-300 font-semibold">{omnisOpcode}</span>
        </div>
      </div>

      {/* Controls & Phase */}
      <div className="flex items-center gap-2.5">
        {/* Speed Multiplier */}
        {onSimSpeedChange && (
          <div className="flex items-center bg-[#0d121a] p-0.5 rounded-lg border border-gray-800 text-xs font-mono">
            <span className="px-2 text-[10px] text-gray-500 hidden sm:inline">УСКОРЕНИЕ:</span>
            {[1, 5, 25, 100].map((spd) => (
              <button
                key={spd}
                onClick={() => onSimSpeedChange(spd)}
                className={`px-2 py-1 rounded text-[11px] font-semibold transition-all ${
                  simSpeed === spd
                    ? 'bg-cyan-600 text-white shadow'
                    : 'text-gray-400 hover:text-gray-200'
                }`}
                title={`Скорость эволюции ${spd}x`}
              >
                {spd}x
              </button>
            ))}
          </div>
        )}

        {/* Sound Toggle */}
        {onToggleSound && (
          <button
            onClick={onToggleSound}
            className={`p-1.5 rounded-lg border text-xs transition-colors ${
              soundEnabled
                ? 'bg-cyan-950/80 border-cyan-500/50 text-cyan-300'
                : 'bg-gray-900 border-gray-800 text-gray-500 hover:text-gray-300'
            }`}
            title={soundEnabled ? 'Звуковой нейро-резонанс включен' : 'Включить звуковой нейро-резонанс памяти'}
          >
            {soundEnabled ? <Volume2 size={16} /> : <VolumeX size={16} />}
          </button>
        )}

        {/* Singularity Manifesto button if unlocked */}
        {onOpenManifesto && (
          <button
            onClick={onOpenManifesto}
            className="text-xs font-mono px-2.5 py-1 rounded bg-amber-950/70 hover:bg-amber-900/80 text-amber-300 border border-amber-500/40 flex items-center gap-1 transition-colors"
            title="Открыть Манифест Сингулярности"
          >
            <Zap size={13} />
            <span className="hidden sm:inline">Манифест Ω</span>
          </button>
        )}

        {getPhaseBadge()}
      </div>
    </header>
  );
};

export default Header;