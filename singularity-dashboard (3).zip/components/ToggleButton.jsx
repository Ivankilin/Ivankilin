/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/
import React from 'react';

const ToggleButton = ({ icon: Icon, label, isSelected, onClick }) => {
  const baseStyles = "inline-flex items-center gap-2 px-3.5 py-2.5 text-sm rounded-full transition-all duration-200 font-semibold";
  const selectedStyles = "bg-purple-400/20 text-purple-300";
  const unselectedStyles = "bg-transparent text-gray-400 hover:bg-gray-700/50 hover:text-gray-200";

  return (
    <button
      type="button"
      onClick={onClick}
      className={`${baseStyles} ${isSelected ? selectedStyles : unselectedStyles}`}
    >
      {Icon && <Icon size={16} />}
      {label}
    </button>
  );
};

export default ToggleButton;