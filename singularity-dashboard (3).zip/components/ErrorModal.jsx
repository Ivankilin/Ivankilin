/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/
import React from 'react';
import { X } from 'lucide-react';
import { Github } from 'lucide-react';

const ErrorModal = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center">
      {/* Semi-opaque blur background */}
      <div
        className="absolute inset-0 bg-black/50 backdrop-blur-sm"
        onClick={onClose}
        onKeyDown={(e) => e.key === 'Escape' && onClose()}
        role="button"
        tabIndex={0}
      />

      {/* Modal card */}
      <div className="relative bg-[#1e1e1e] rounded-2xl p-8 shadow-lg border border-gray-700 max-w-lg mx-4 z-10">
        <button
          type="button"
          onClick={onClose}
          className="absolute top-4 right-4 text-gray-500 hover:text-gray-300 transition-colors"
        >
          <X size={24} />
        </button>

        <h2 className="text-xl font-bold text-white mb-4">
          Something went wrong
        </h2>

        <p className="text-gray-400 mb-4">
          This could be an issue with the API key or the connection. Want to run it yourself? Get the code and run it locally!
        </p>

        <p className="text-gray-400 mb-8">
          You can get your own API key from{' '}
          <a
            href="https://ai.google.dev"
            target="_blank"
            rel="noopener noreferrer"
            className="text-cyan-400 hover:text-cyan-300 underline"
          >
            ai.google.dev
          </a>
          {' '}to start using this right away.
        </p>

        <div className="flex gap-4 justify-center">
          <a
            href="https://github.com/googlecreativelab/gemini-demos/tree/main/image-to-code"
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center gap-2 px-4 py-2 bg-gray-200 text-black rounded-lg hover:bg-white transition-colors font-semibold"
          >
            <Github size={20} />
            <span>Get the code on GitHub</span>
          </a>

          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 border border-gray-600 rounded-lg text-gray-300 hover:bg-gray-700 hover:border-gray-500 transition-colors"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};

export default ErrorModal;