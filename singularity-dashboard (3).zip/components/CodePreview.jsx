/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/
/**
 * Copyright 2025 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import React, { useState } from 'react';
import { Code2, Play, Copy, Check, MessageCircle } from 'lucide-react';
import Editor from '@monaco-editor/react';
import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm';
import ToggleButton from './ToggleButton';

const CodePreview = ({ output, onCodeChange, fullResponse }) => {
  const [showCode, setShowCode] = useState(false);
  const [showReasoning, setShowReasoning] = useState(false);
  const [isCopied, setIsCopied] = useState(false);

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(output.code);
      setIsCopied(true);
      setTimeout(() => setIsCopied(false), 2000);
    } catch (err) {
      console.error('Failed to copy code:', err);
    }
  };

  const renderSketch = (code) => {
    // Make sure we're working with a string
    const codeString = typeof code === 'string' ? code : code.toString();

    const wrappedCode = `
      function setup() {
        let canvas = createCanvas(500, 500);
        canvas.parent('p5-canvas-container');
        ${codeString.includes('setup()') ? '' : codeString}
      }
      ${codeString.includes('setup()') ? codeString.substring(codeString.indexOf('setup()')) : ''}
    `;

    const formattedCodeResponse = `
      <!DOCTYPE html>
      <html lang="en">
      <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <script src="https://cdnjs.cloudflare.com/ajax/libs/p5.js/1.9.0/p5.js"></script>
        <title>p5.js Sketch</title>
        <style>
          body {
            padding: 0;
            margin: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            background-color: #1a1a1a;
            height: 100vh;
            overflow: hidden;
          }
        </style>
      </head>
      <body>
        <div id="p5-canvas-container"></div>
        <script>
          try {
            ${wrappedCode}
          } catch (error) {
            console.error('Sketch error:', error);
            document.body.innerHTML = '<div style="color: #ff6b6b; padding: 20px; font-family: monospace;"><h3>🔴 Error:</h3><pre>' + error.message + '</pre></div>';
          }
        </script>
      </body>
      </html>
    `;

    return (
      <div className="relative w-full h-[500px] bg-gray-900 rounded-lg overflow-hidden">
        <iframe
          srcDoc={formattedCodeResponse}
          title="p5.js Sketch"
          width="100%"
          height="100%"
          style={{ border: "none" }}
          className="absolute inset-0"
          sandbox="allow-scripts"
        />
      </div>
    );
  };

  // Make sure we're passing the actual code string to renderSketch
  const sketchCode = output?.code || '';

  return (
    <div className="bg-transparent">
      <div className="mb-4">
        {showCode ? (
          <div className="w-full h-[500px] rounded-lg overflow-hidden border border-gray-700">
            <Editor
              height="500px"
              defaultLanguage="javascript"
              value={sketchCode}
              onChange={(value) => onCodeChange(output.id, value)}
              theme="vs-dark"
              options={{
                minimap: { enabled: false },
                fontSize: 12,
                lineNumbers: 'on',
                scrollBeyondLastLine: false,
                automaticLayout: true,
                tabSize: 2,
                wordWrap: 'on',
                padding: { top: 16, bottom: 16 }
              }}
            />
          </div>
        ) : showReasoning ? (
          <div className="w-full h-[500px] rounded-lg overflow-y-auto border border-gray-700 p-6 bg-gray-900 prose prose-sm prose-invert max-w-none">
            <ReactMarkdown remarkPlugins={[remarkGfm]}>
              {fullResponse}
            </ReactMarkdown>
          </div>
        ) : (
          renderSketch(sketchCode)
        )}
      </div>

      <div className="flex flex-col sm:flex-row justify-between items-center gap-3 mt-4">
        <div className="inline-flex rounded-full bg-gray-800 p-1 gap-1 w-full sm:w-auto justify-center">
          <ToggleButton
            icon={Play}
            label="Preview"
            isSelected={!showCode && !showReasoning}
            onClick={() => {
              setShowCode(false);
              setShowReasoning(false);
            }}
          />
          <ToggleButton
            icon={MessageCircle}
            label="Reasoning"
            isSelected={showReasoning}
            onClick={() => {
              setShowCode(false);
              setShowReasoning(true);
            }}
          />
          <ToggleButton
            icon={Code2}
            label="Code"
            isSelected={showCode}
            onClick={() => {
              setShowCode(true);
              setShowReasoning(false);
            }}
          />
        </div>
        <button
          type="button"
          onClick={handleCopy}
          className={`px-3.5 py-2.5 rounded-full transition-colors inline-flex text-sm border
            items-center gap-2 w-full sm:w-auto justify-center font-semibold ${
            isCopied
              ? "bg-purple-500 text-white border-transparent"
              : "bg-gray-800 text-gray-300 border-gray-700 hover:bg-gray-700"
          }`}
        >
          {isCopied ? (
            <>
              <Check size={16} />
              Copied!
            </>
          ) : (
            <>
              <Copy size={16} />
              Copy Code
            </>
          )}
        </button>
      </div>
    </div>
  );
};

export default CodePreview;