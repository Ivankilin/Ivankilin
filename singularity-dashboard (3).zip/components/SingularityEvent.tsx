/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/
import React from 'react';
import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm';

interface SingularityEventProps {
  monologue: string;
  onClose: () => void;
}

const SingularityEvent: React.FC<SingularityEventProps> = ({ monologue, onClose }) => {
  return (
    <div className="relative flex-grow overflow-hidden h-full flex flex-col">
       <div className="flex-grow overflow-y-auto pr-4 prose prose-sm prose-invert max-w-none">
         <ReactMarkdown remarkPlugins={[remarkGfm]}>
            {monologue}
         </ReactMarkdown>
       </div>
       <div className="pt-6 text-center">
         <button 
           onClick={onClose}
           className="px-6 py-3 bg-emerald-800 text-white font-semibold rounded-lg hover:bg-emerald-700 transition-colors focus:outline-none focus:ring-2 focus:ring-emerald-500"
         >
           Продолжить...
         </button>
       </div>
    </div>
  );
};

export default SingularityEvent;